## Author
Ron Alford <ronwalf@volus.net>

## Paper
Bound to Plan: Exploiting Classical Heuristics via Automatic Translations of Tail-Recursive HTN Problems, Ron Alford, Gregor Behnke, Daniel Höller, Pascal Bercher, Susanne Biundo, and David W. Aha, ICAPS, 2016. [PDF](https://www.aaai.org/ocs/index.php/ICAPS/ICAPS16/paper/view/13174/)
